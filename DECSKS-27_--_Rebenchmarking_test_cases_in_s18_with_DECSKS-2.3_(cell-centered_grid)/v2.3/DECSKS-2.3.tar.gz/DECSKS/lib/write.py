import DECSKS

def outputs(f,t,x,v,n):

    

    return None
